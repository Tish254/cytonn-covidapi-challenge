export { default as Dashboard } from "./dashboard/Dashboard";
export { default as CovidStatistics } from "./statistics/CovidStatistics";
export { default as CovidHistory } from "./history/CovidHistory";
